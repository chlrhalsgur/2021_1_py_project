from server_f import app

app.run(host='0.0.0.0', port=5000)